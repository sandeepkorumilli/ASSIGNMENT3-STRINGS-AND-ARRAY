package sTRINGS;

import java.util.Arrays;
import java.util.Scanner;

public class Question3 {
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the first string to check whether its anagram or not :");
		String a = sc.nextLine();
		System.out.println("Enter the Second string to check whether its anagram or not :");
		String b = sc.nextLine();
		///covert string in to array format
		a = a.replace(" ", "");
		b = b.replace(" ", "");///To avoid spaces
		///coverting string to lower character string
		a = a.toLowerCase();
		b = b.toLowerCase();
		
		char x[] = a.toCharArray();
		char y[] = b.toCharArray();
		///sorting the Array
		Arrays.sort(x);
		Arrays.sort(y);
		///Checking the result
		Boolean res = Arrays.equals(x,y);
		if(res==true)
		{
			System.out.println(a+" and "+b+ " both are Anagram");
		}
		else
		{
			System.out.println(a+" and "+b+ " both are  not Anagram");
		}
		
		
	}

}
