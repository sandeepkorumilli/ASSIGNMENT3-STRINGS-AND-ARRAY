package sTRINGS;

import java.util.Arrays;
import java.util.Scanner;

public class Question6 {

	 public static void main(String args[])
	  {
		  System.out.print("Enter the String : ");
		  Scanner sc = new Scanner(System.in);
		  String str = sc.nextLine();
		  str = str.replace(" ", "");
		  str = str.toLowerCase();
		  char ch[] = str.toCharArray();
		  Arrays.sort(ch);
		  System.out.println(ch);
	  }
}

//WITHOUT USING DIRECT SORT_METHOD
/*public static void main(String args[])
{
	System.out.println("Enter the String");
	Scanner sc = new Scanner(System.in);
	String str = sc.nextLine();
	str = str.toLowerCase();
	str = str.replace(" ","");
	char carr[] = str.toCharArray();
	char temp;
	for(int i=0;i<str.length();i++)
	{
		for(int j=i+1;j<str.length();j++)
		{
			if(carr[i]>carr[j])
			{
				temp = carr[i];
			    carr[i] = carr[j];
			    carr[j] = temp;
			}
		}
	}
	System.out.println(new String(carr));
}*/