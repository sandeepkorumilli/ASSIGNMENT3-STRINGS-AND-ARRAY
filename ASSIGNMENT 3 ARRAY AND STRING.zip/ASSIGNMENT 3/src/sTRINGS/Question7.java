package sTRINGS;

import java.util.Scanner;

public class Question7 {

	public static void main(String args[])
	{
		//String x = "THIS IS VOWEL AND CONSONANT COUNT PROGRAM";
		System.out.println("Enter the String");
		Scanner sc = new Scanner(System.in);
		
		String x = sc.nextLine();
		x = x.replace(" ", "");
		
		///coverting string to upper character string
		x = x.toUpperCase();
		//System.out.println(x);
		char y[] = x.toCharArray();
		int size = y.length;
		int vowelcount = 0;
		int consonantcount = 0;
		int specialcharcount = 0;
		 int i=0;
		 while(i!=size)
		 {
			 if(y[i]>='A' && y[i]<='Z')
			 {
				 if(y[i]=='A'||y[i]=='E'||y[i]=='I'||y[i]=='O'||y[i]=='U')
				 {
					 vowelcount++;
				 }
				 else
				 {
					 consonantcount++;
				 }
				 
			 }
			 else {
				  specialcharcount++;
			 }
			++i;
		 }
		
		 System.out.println(y);
			System.out.println("No of Vowels are "+vowelcount);
			System.out.println("No of Consonants are "+consonantcount);
			System.out.println("No of SpecialCharacters are "+specialcharcount);
		
	}
}
