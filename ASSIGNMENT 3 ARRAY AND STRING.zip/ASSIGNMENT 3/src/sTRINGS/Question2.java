package sTRINGS;

import java.util.Scanner;

public class Question2 {

	public static void main(String args[])
	{
		System.out.println("Enter the string value");
		Scanner st = new Scanner(System.in);
		 String s = st.nextLine();
		 String s1 = " ";
		 
		 
		 for(int i= s.length()-1;i>=0;i--)
		 {
			 s1 = s1.toLowerCase();
			 s1 = s1+s.charAt(i);
		 }
		 String s2 = " ";
		
		 String arr[] = s1.split(" ");
		 for(int i=arr.length-1;i>=0;i--)
		 {
			 s2 = s2.toLowerCase();
			 s2 = s2+arr[i]+" ";
		 }
		 System.out.println(s2);
	}
	
}
