package sTRINGS;

import java.util.Scanner;

public class Question8 {

	public static void main(String args[])
	{
		//String x = "THIS IS VOWEL AND CONSONANT COUNT PROGRAM";
		System.out.println("Enter the String");
		Scanner sc = new Scanner(System.in);
		
		String x = sc.nextLine();
		x = x.replace(" ", "");
		
		///coverting string to lower character string
		x = x.toUpperCase();
		
		char y[] = x.toCharArray();
		int size = y.length;
		
		int lettercount = 0;
		int specialcharcount = 0;
		 int i=0;
		 while(i!=size)
		 {
			 if(y[i]>='A' && y[i]<='Z')
			 {
				++lettercount;
				 
			 }
			else {
				  ++specialcharcount;
			 }
			++i;
		 }
		
		 System.out.println(y);
			
			System.out.println("No of SpecialCharacters are "+specialcharcount);
		
	}
}
